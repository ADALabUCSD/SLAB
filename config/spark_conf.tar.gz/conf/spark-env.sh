#!/usr/bin/env bash

#export SPARK_LOCAL_DIRS="TODO"
export SPARK_LOCAL_DIRS="/tmp"

# Standalone cluster options
#export SPARK_MASTER_OPTS="TODO"
#if [ -n "TODO" ]; then
#  export SPARK_WORKER_INSTANCES=TODO
#fi
export SPARK_WORKER_CORES=24

export HADOOP_HOME="/usr/local/hadoop-2.7.3"
export HADOOP_CONF_DIR="/usr/local/hadoop-2.7.3/etc/hadoop"
export SPARK_MASTER_IP=""
#export MASTER=`cat /root/spark-ec2/cluster-url`

export SPARK_SUBMIT_LIBRARY_PATH="$SPARK_SUBMIT_LIBRARY_PATH:/usr/local/hadoop-2.7.3/lib/native/"
export SPARK_SUBMIT_CLASSPATH="$SPARK_CLASSPATH:$SPARK_SUBMIT_CLASSPATH:$HADOOP_CONF_DIR:/usr/local/hadoop-2.7.3/share"

# Bind Spark's web UIs to this machine's public EC2 hostname otherwise fallback to private IP:
export SPARK_PUBLIC_DNS=`wget -q -O - http://169.254.169.254/latest/meta-data/public-ipv4`

# Used for YARN model
export YARN_CONF_DIR="/usr/local/hadoop-2.7.3/etc/hadoop/"

# Set a high ulimit for large shuffles, only root can do this
if [ $(id -u) == "0" ]
then
    ulimit -n 1000000
fi

export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/usr/local/hadoop-2.7.3/lib/native"